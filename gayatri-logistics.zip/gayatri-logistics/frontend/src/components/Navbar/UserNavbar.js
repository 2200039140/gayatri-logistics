import React from 'react';
import './UserNavbar.css'

const UserNavbar = () => {
  return (
    <nav className='nav'>
        <a href="/" className="site-title"> Site Title</a>
        <ul>
            <li>  <a href='/get-estimate'> Get Estimate </a></li>
            <li>  <a href='/book-order'> Book Order </a></li>
            <li>  <a href='/track-order'> Track Order</a></li>
        </ul>
    </nav>    
  )
}

export default UserNavbar
