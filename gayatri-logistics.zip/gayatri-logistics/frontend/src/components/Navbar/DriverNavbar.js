import React from 'react';
import './UserNavbar.css'

const DriverNavbar = () => {
  return (
    <nav className='nav'>
        <a href="/" className="site-title"> Site Title</a>
        <ul>
            <li>  <a href='/job-assignment'> Get Order </a></li>
            <li>  <a href='/job-status'> Job Status </a></li>
        </ul>
    </nav>    
  )
}

export default DriverNavbar
