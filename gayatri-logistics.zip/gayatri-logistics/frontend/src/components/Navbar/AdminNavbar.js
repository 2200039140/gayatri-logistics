import React from 'react';
import './UserNavbar.css'

const AdminNavbar = () => {
  return (
    <nav className='nav'>
        <a href="/" className="site-title"> Site Title</a>
        <ul>
            <li>  <a href='/fleet-management'> Get Order </a></li>
            <li>  <a href='/data-analytics'> Job Status </a></li>
        </ul>
    </nav>    
  )
}

export default AdminNavbar
