import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import 'leaflet-routing-machine';

// Fix default marker icons for leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

const GetEstimate = () => {
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropOffLocation, setDropOffLocation] = useState('');
  const [pickupCoords, setPickupCoords] = useState(null);
  const [dropOffCoords, setDropOffCoords] = useState(null);
  const [vehicleType, setVehicleType] = useState('');
  const [estimatedCost, setEstimatedCost] = useState(0);
  const [distance, setDistance] = useState(0);
  const [map, setMap] = useState(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState(''); // New email state
  const [address, setAddress] = useState('');
  const [mobile, setMobile] = useState('');
  const [isBooking, setIsBooking] = useState(false); // Show booking form when true

  // Function to calculate the Haversine distance
  const haversineDistance = (coords1, coords2) => {
    const toRad = (Value) => (Value * Math.PI) / 180;
    const lat1 = coords1[0];
    const lon1 = coords1[1];
    const lat2 = coords2[0];
    const lon2 = coords2[1];
    const R = 6371; // Radius of Earth in kilometers
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in kilometers
  };

  // Function to get the coordinates of an address using OpenStreetMap's Nominatim API with fetch
  const getCoordsFromAddress = async (address) => {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${address}`);
      const data = await response.json();
      const { lat, lon } = data[0]; // Get the first result
      return [parseFloat(lat), parseFloat(lon)];
    } catch (error) {
      console.error('Error getting coordinates:', error);
      return null;
    }
  };

  // Move map to a new location and add marker
  const MoveToLocation = ({ coords }) => {
    const mapInstance = useMap();
    useEffect(() => {
      if (coords) {
        mapInstance.setView(coords, 13);
      }
    }, [coords, mapInstance]);
    return coords ? <Marker position={coords}><Popup>{coords.toString()}</Popup></Marker> : null;
  };

  // Function to handle cost estimation
  const handleCostEstimation = () => {
    if (pickupCoords && dropOffCoords) {
      const calculatedDistance = haversineDistance(pickupCoords, dropOffCoords);
      setDistance(calculatedDistance);

      const costPerKm = vehicleType === 'lorry' ? 20 : vehicleType === 'truck' ? 25 : 30; // Cost logic
      setEstimatedCost(calculatedDistance * costPerKm);

      // Show route on the map
      if (map) {
        L.Routing.control({
          waypoints: [
            L.latLng(pickupCoords[0], pickupCoords[1]),
            L.latLng(dropOffCoords[0], dropOffCoords[1]),
          ],
          routeWhileDragging: true,
        }).addTo(map);
      }
    }
  };

  // Handle booking submission with fetch
  const handleBooking = async () => {
    const bookingData = {
      name,
      email, // Include email in the booking data
      address,
      mobile,
      pickupLocation,
      dropOffLocation,
      vehicleType,
      estimatedCost,
      distance,
    };

    try {
      const response = await fetch('http://localhost:8000/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`, // Include token if authentication is required
        },
        body: JSON.stringify(bookingData),
      });

      if (response.ok) {
        alert('Booking Successful!');
        // Reset form
        setName('');
        setEmail(''); // Reset email field
        setAddress('');
        setMobile('');
        setIsBooking(false);
      } else {
        alert('Error in booking. Please try again.');
      }
    } catch (error) {
      console.error('Booking failed:', error);
      alert('Booking failed. Please try again.');
    }
  };

  // Update map when input fields change
  useEffect(() => {
    const updateCoordsFromInput = async () => {
      if (pickupLocation) {
        const coords = await getCoordsFromAddress(pickupLocation);
        if (coords) setPickupCoords(coords);
      }

      if (dropOffLocation) {
        const coords = await getCoordsFromAddress(dropOffLocation);
        if (coords) setDropOffCoords(coords);
      }
    };
    updateCoordsFromInput();
  }, [pickupLocation, dropOffLocation]);

  return (
    <div style={styles.container}>
      {/* Form component */}
      <div style={styles.formContainer}>
        <h2 style={styles.title}>Book a Vehicle</h2>

        <input
          type="text"
          placeholder="Pickup Location"
          value={pickupLocation}
          onChange={(e) => setPickupLocation(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Drop-Off Location"
          value={dropOffLocation}
          onChange={(e) => setDropOffLocation(e.target.value)}
          style={styles.input}
        />

        <select value={vehicleType} onChange={(e) => setVehicleType(e.target.value)} style={styles.select}>
          <option value="">Select Vehicle Type</option>
          <option value="truck">Truck</option>
          <option value="lorry">Lorry</option>
          <option value="containerLorry">Container Lorry</option>
        </select>

        <button onClick={handleCostEstimation} style={styles.button}>Estimate Cost</button>

        {estimatedCost > 0 && (
          <>
            <p style={styles.resultText}>Estimated Distance: {distance.toFixed(2)} km</p>
            <p style={styles.resultText}>Estimated Cost: ₹{estimatedCost.toFixed(2)}</p>

            <button onClick={() => setIsBooking(true)} style={styles.bookNowButton}>Book Now</button>

            {isBooking && (
              <div style={styles.bookingForm}>
                <h3>Enter Your Details</h3>
                <input
                  type="text"
                  placeholder="Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={styles.input}
                />
                <input
                  type="email"
                  placeholder="Email" // New email input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={styles.input}
                />
                <input
                  type="text"
                  placeholder="Address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  style={styles.input}
                />
                <input
                  type="text"
                  placeholder="Mobile Number"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  style={styles.input}
                />
                <button onClick={handleBooking} style={styles.submitButton}>Submit Booking</button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Map component */}
      <div style={styles.mapContainer}>
        <MapContainer
          center={[51.505, -0.09]} // Default center
          zoom={13}
          style={styles.map}
          whenCreated={setMap}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
          />
          <MoveToLocation coords={pickupCoords} />
          <MoveToLocation coords={dropOffCoords} />
        </MapContainer>
      </div>
    </div>
  );
};

const styles = {
  // Add your custom styles here
  container: { display: 'flex', flexDirection: 'column', alignItems: 'center' },
  formContainer: { width: '80%', maxWidth: '600px', marginBottom: '20px' }, // Form container styling
  title: { fontSize: '24px', marginBottom: '10px' }, // Title styling
  input: { width: '100%', padding: '10px', margin: '10px 0' }, // Input field styling
  select: { width: '100%', padding: '10px', margin: '10px 0' }, // Select dropdown styling
  button: { padding: '10px 20px', margin: '10px 0', cursor: 'pointer' }, // Button styling
  resultText: { fontSize: '18px', marginTop: '10px' }, // Result text styling
  bookNowButton: { padding: '10px 20px', backgroundColor: '#4CAF50', color: 'white', cursor: 'pointer' }, // Book now button
  bookingForm: { marginTop: '20px' }, // Booking form styling
  submitButton: { padding: '10px 20px', backgroundColor: '#4CAF50', color: 'white', cursor: 'pointer' }, // Submit button styling
  mapContainer: { width: '100%', height: '400px' }, // Map container styling
  map: { width: '100%', height: '100%' } // Map styling
};

export default GetEstimate;