const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB Atlas Connection URI
const mongoURI = `mongodb+srv://admin:${process.env.DB_PASSWORD}@cluster0.qu1zycp.mongodb.net/your_database_name?retryWrites=true&w=majority&appName=Cluster0`;

mongoose.connect(mongoURI)
  .then(() => {
    console.log('MongoDB connected successfully');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });

// Define User Schema
const userSchema = new mongoose.Schema({
  id: { type: Number, required: false },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['user', 'driver'], required: true },
  licenseNumber: { type: String },
  vehicleDetails: { type: String },
});

// Define Booking Schema
const bookingSchema = new mongoose.Schema({
  name: { type: String, required: true },
  address: { type: String, required: true },
  mobile: { type: String, required: true },
  pickupLocation: { type: String, required: true },
  dropOffLocation: { type: String, required: true },
  vehicleType: { type: String, required: true },
  estimatedCost: { type: Number, required: true },
  distance: { type: Number, required: true },
  email: { type: String, required: true },
  status: { type: String, required: true, default: 'pending' },
  latitude: { type: String, default: null },
  longitude: { type: String, default: null },
  driverId: { type: String, default: null },
  currentStatus: { type: String, default: null }
});

// Create User and Booking Models
const User = mongoose.model('User', userSchema);
const Booking = mongoose.model('Booking', bookingSchema);

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(403).json({ message: 'Token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Simple route to verify server is running
app.get('/', (req, res) => {
  res.send('Welcome to the Logistics Platform API!');
});

// Fetch all pending jobs (bookings)
app.get('/api/bookings/pending', async (req, res) => {
  try {
    const pendingJobs = await Booking.find({ status: 'pending' });
    res.status(200).json(pendingJobs);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching pending bookings' });
  }
});

// Update booking status to accepted or rejected
app.put('/api/bookings/:id', async (req, res) => {
  const { status } = req.body;
  try {
    const updatedBooking = await Booking.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.status(200).json(updatedBooking);
  } catch (error) {
    res.status(500).json({ message: 'Error updating booking status' });
  }
});

// Update booking with latitude and longitude
app.put('/api/bookings/:id/location', async (req, res) => {
  const { latitude, longitude } = req.body;
  try {
    const updatedBooking = await Booking.findByIdAndUpdate(
      req.params.id,
      { latitude, longitude },
      { new: true }
    );
    res.status(200).json(updatedBooking);
  } catch (error) {
    res.status(500).json({ message: 'Error updating booking location' });
  }
});

// Job Assignment API
app.put('/api/assign-job/:id', async (req, res) => {
  const { driverId } = req.body;
  try {
    const updatedBooking = await Booking.findByIdAndUpdate(req.params.id, { driverId }, { new: true });
    res.status(200).json(updatedBooking);
  } catch (error) {
    res.status(500).json({ message: 'Error assigning job' });
  }
});

// Job Status API
app.put('/api/bookings/:jobId/status', async (req, res) => {
  const { jobId } = req.params;
  const { currentStatus } = req.body;

  try {
    const job = await Booking.findByIdAndUpdate(jobId, { currentStatus }, { new: true });
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    res.json(job);
  } catch (error) {
    res.status(500).json({ message: 'Error updating job status' });
  }
});

// Fetch jobs assigned to a specific driver
app.get('/api/bookings/:driverId', async (req, res) => {
  const driverId = req.params.driverId;
  try {
    const jobs = await Booking.find({ driverId: driverId });
    res.status(200).json(jobs);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching jobs for driver' });
  }
});

// Booking route - Create a new booking
app.post('/api/bookings', async (req, res) => {
  const { name, email, address, mobile, pickupLocation, dropOffLocation, vehicleType, estimatedCost, distance } = req.body;

  try {
    const newBooking = new Booking({
      name,
      email,
      address,
      mobile,
      pickupLocation,
      dropOffLocation,
      vehicleType,
      estimatedCost,
      distance,
    });

    await newBooking.save();

    res.status(200).json({ message: 'Booking Successful!', booking: newBooking });
  } catch (error) {
    res.status(500).json({ message: 'Error creating booking', error });
  }
});

// Booking History route - Get all bookings by user email
app.get('/api/bookings/:email', async (req, res) => {
  const userEmail = req.params.email;

  try {
    const bookings = await Booking.find({ email: userEmail });

    if (!bookings.length) {
      return res.status(404).json({ message: 'No bookings found' });
    }

    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching booking history' });
  }
});

// Fetch All Users for Admin
app.get('/api/admin/users', async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users' });
  }
});

// Fetch All Drivers for Admin
app.get('/api/admin/drivers', async (req, res) => {
  try {
    const drivers = await User.find({ role: 'driver' });
    res.status(200).json(drivers);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching drivers' });
  }
});

// Fetch Current Orders for Admin (excluding delivered)
app.get('/api/admin/current-orders', async (req, res) => {
  try {
    const currentOrders = await Booking.find({ status: { $ne: 'delivered' } });
    res.status(200).json(currentOrders);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching current orders' });
  }
});

// Fetch Delivered Orders for Admin
app.get('/api/admin/delivered-orders', async (req, res) => {
  try {
    const deliveredOrders = await Booking.find({ status: 'delivered' });
    res.status(200).json(deliveredOrders);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching delivered orders' });
  }
});

// User Registration
app.post('/api/register', async (req, res) => {
  const { name, email, password, role, licenseNumber, vehicleDetails } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      role,
      licenseNumber: role === 'driver' ? licenseNumber : undefined,
      vehicleDetails: role === 'driver' ? vehicleDetails : undefined,
    });

    await newUser.save();
    res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    res.status(400).json({ message: 'Error registering user', error });
  }
});

// User Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(200).json({ token, user });
  } catch (error) {
    res.status(500).json({ message: 'Error logging in', error });
  }
});

// Start the server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});